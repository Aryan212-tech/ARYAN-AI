# ARYAN AI Documentation

## Overview
ARYAN AI is a modern AI chatbot with a ChatGPT-like interface that uses Gemini Flash 2.0 API for intelligent responses. This documentation provides information on how to use, deploy, and customize the application.

## Features
- Modern, responsive UI that works on both mobile and desktop devices
- Real-time chat interface with AI responses
- Dark/light mode support
- Conversation history management
- Integration with Gemini Flash 2.0 API

## Project Structure
```
aryan-ai/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   └── chat/
│   │   │       └── route.ts      # API endpoint for chat functionality
│   │   ├── globals.css           # Global styles
│   │   ├── layout.tsx            # Root layout component
│   │   └── page.tsx              # Main page component
│   ├── components/
│   │   ├── chat/
│   │   │   ├── ChatInput.tsx     # Chat input component
│   │   │   ├── ChatMessage.tsx   # Individual message component
│   │   │   └── ChatMessages.tsx  # Message container component
│   │   └── sidebar/
│   │       └── Sidebar.tsx       # Sidebar component
│   └── lib/
│       ├── chat-service.ts       # Chat service utility
│       └── gemini-service.ts     # Gemini API service
├── public/                       # Static assets
├── package.json                  # Project dependencies
├── next.config.ts                # Next.js configuration
└── vercel.json                   # Vercel deployment configuration
```

## Deployment Instructions

### Option 1: Deploy to Vercel (Recommended)
1. Create a Vercel account at https://vercel.com if you don't have one
2. Install the Vercel CLI: `npm install -g vercel`
3. Extract the provided `aryan-ai-deployment.zip` file
4. Navigate to the extracted directory
5. Run `vercel login` and follow the authentication steps
6. Run `vercel deploy --prod`
7. Your application will be deployed to a URL like `aryan-ai-[username].vercel.app`

### Option 2: Deploy to Other Hosting Services
1. Extract the provided `aryan-ai-deployment.zip` file
2. Navigate to the extracted directory
3. Run `npm install` to install dependencies
4. Run `npm run build` to build the application
5. Deploy the `.next` directory and other necessary files according to your hosting provider's instructions

## Customization

### Changing the API Key
To use your own Gemini Flash 2.0 API key:
1. Open `src/app/api/chat/route.ts`
2. Replace `YOUR_GEMINI_API_KEY` with your actual API key

### Customizing the UI
- **Colors and Styling**: Edit `src/app/globals.css` to change the color scheme and styling
- **Logo and Branding**: Replace the "ARYAN AI" text in `src/components/sidebar/Sidebar.tsx` and `src/app/layout.tsx`
- **Welcome Message**: Edit the welcome message in `src/components/chat/ChatMessages.tsx`

### Adding New Features
- **User Authentication**: Implement user authentication to save conversations per user
- **Multiple AI Models**: Add support for different AI models by extending the API route
- **File Uploads**: Implement file upload functionality for document analysis

## Troubleshooting

### Common Issues
- **API Key Issues**: If you're getting errors with the Gemini API, verify your API key is correct
- **Build Errors**: Make sure all dependencies are installed with `npm install`
- **Deployment Issues**: Ensure your hosting provider supports Next.js applications

### Support
For additional support or questions, please contact the developer.

## License
This project is licensed under the MIT License.
