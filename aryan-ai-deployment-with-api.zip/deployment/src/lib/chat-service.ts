import axios from 'axios';

// Types for chat messages
export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

// Function to send a message to the AI and get a response
export async function sendMessageToAI(message: string): Promise<Message> {
  try {
    const response = await axios.post('/api/chat', { message });
    return {
      role: 'assistant',
      content: response.data.response
    };
  } catch (error) {
    console.error('Error sending message to AI:', error);
    return {
      role: 'assistant',
      content: 'Sorry, I encountered an error processing your request. Please try again.'
    };
  }
}
