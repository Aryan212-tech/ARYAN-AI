import React from 'react';

interface ChatMessageProps {
  message: {
    role: 'user' | 'assistant';
    content: string;
  };
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.role === 'user';
  
  return (
    <div className={`py-5 ${isUser ? 'message-user' : 'message-ai'}`}>
      <div className="mx-auto flex max-w-4xl px-4">
        <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gray-300 dark:bg-gray-700">
          {isUser ? (
            <span className="text-sm font-medium">U</span>
          ) : (
            <span className="text-sm font-medium">AI</span>
          )}
        </div>
        <div className="flex-1 space-y-2 overflow-hidden">
          <p className="font-semibold">{isUser ? 'You' : 'ARYAN AI'}</p>
          <div className="prose dark:prose-invert">
            {message.content}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
