import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';

// Gemini Flash 2.0 API endpoint
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-2.0:generateContent';
// User's Gemini API key
const API_KEY = 'AlzaSyAu-maFeAfEgcyYADsklToHEZz9QcYs6stDA';

export async function POST(req: NextRequest) {
  try {
    const { message } = await req.json();
    
    // Use Gemini API with the provided key
    try {
      const response = await axios.post(
        `${GEMINI_API_URL}?key=${API_KEY}`,
        {
          contents: [
            {
              role: 'user',
              parts: [{ text: message }]
            }
          ],
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 800,
          }
        }
      );
      
      // Extract the response text from Gemini API
      const aiResponse = response.data.candidates[0].content.parts[0].text;
      
      return NextResponse.json({ 
        response: aiResponse,
        role: 'assistant'
      });
    } catch (apiError) {
      console.error('Error calling Gemini API:', apiError);
      // Fall back to simulated responses if API call fails
      return simulatedResponse();
    }
  } catch (error) {
    console.error('Error processing chat request:', error);
    return NextResponse.json(
      { error: 'Failed to process your request' },
      { status: 500 }
    );
  }
}

// Function to provide simulated responses when API is not available
function simulatedResponse() {
  const responses = [
    "Hello! I'm ARYAN AI, your personal AI assistant powered by Gemini Flash 2.0. How can I help you today?",
    "That's an interesting question. Based on my knowledge, I would suggest...",
    "I understand what you're asking. Let me analyze that for you...",
    "Thank you for sharing that with me. Is there anything specific you'd like to know about this topic?",
    "I'm designed to assist with a wide range of topics. What else would you like to discuss?",
    "That's a great point! I appreciate your perspective on this matter.",
    "I'm continuously learning to provide better responses. Your questions help me improve.",
    "Let me process that request and provide you with the most helpful information I can."
  ];
  
  // Select a random response
  const randomResponse = responses[Math.floor(Math.random() * responses.length)];
  
  return NextResponse.json({ 
    response: randomResponse,
    role: 'assistant'
  });
}
